# Install mariadb on a workstation.

sudo mysql_secure_installation

# It would then be necessary to create a user as well as a database

CREATE DATABASE name_db CHARACTER SET UTF8;
CREATE USER 'db_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON name_db.* TO 'db_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Afterwards, install the mysqlclient to connect django to MariaDB""

pip install mysqlclient

# Within the django project settings, update the databases configuration in settings.py

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'name_db',
        'USER': 'db_user',
        'PASSWORD': 'password',
        'HOST': 'localhost',  # Or the server IP if it's a remote server
        'PORT': '3306',
    }
}

# Ensure that Django identifies the new database

python manage.py makemigrations
python manage.py migrate

# Apply migrations

python manage.py migrate

# Create a super user or admin

python manage.py createsuperuser

# Test it on the server

python manage.py runserver