// ajax call for adding notes to the DB from the HTML form
function addNotes() {	
	$.ajax(
		{
			url: '/add_note/',
			type: "POST",
			dataType: "json",
			data: $(".frmAddNote").serialize(),
			success: location.href = '/',
		})
	}
	
// ajax call for updating an existing note in the DB using values from HTML input 
function editNotes(noteID) {	
	$.ajax({
		url : '/edit_note/',
		type: 'PUT',
		data: $.param({noteID: noteID, noteTitleField: $("#editNoteTitleID"+noteID).val(),  noteDescriptionField: $("#editNoteDescriptionID"+noteID).val()}),
		dataType: 'json',
		success: viewNotes,
	})
}

// ajax call for delete an existing note from the DB
function deleteNotes(noteID) {
	if(confirm("Are you sure you want to delete this note?")) {
		$.ajax({
			url : '/remove_note/',
      type: 'DELETE',
      data: $.param({noteID: noteID}),
      dataType: 'json',
      success: viewNotes,
    })
  }
}

// ajax call for getting all note records from the DB
function viewNotes() { 
	$.ajax(
		{
			url: '/fetch_notes/',
			type: 'GET',
			dataType: 'json',
			success: outputNotesResponse,
		})
}

//looping through response data from the GET request above
function outputNotesResponse(response) {
	var outputNotes = "";
	
	for(var i=0; i<response.notes.length; i++)
	{		
		var currentNote = response.notes[i];
		
		outputNotes += "<div class='sticky-note'>" +
		
		"<input type='text' value='"+currentNote.noteTitle+"' class='editNoteTitle' name=''titleOfNote"+currentNote.id+"' id='editNoteTitleID"+currentNote.id+"' />" +
		
		"<textarea class='editNoteDescription' id='editNoteDescriptionID"+currentNote.id+"'>" +
		currentNote.noteDescription+"</textarea>" +
		
		"<input type='button' onclick='editNotes("+currentNote.id+")' value='Update' />" +
		"<input type='button' onclick='deleteNotes("+currentNote.id+")' value='Delete' />" +		
		
		"</div>";
	}

	$('#outputNotes').html(outputNotes)
}

viewNotes();