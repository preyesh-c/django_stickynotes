from django.urls import path
from . import views

app_name = 'sticky_notes'
urlpatterns = [
    #urls for loading pages for viewing and adding notes
    path('', views.index, name='index'),
    path('add-note', views.loadAddNote, name='directory'),
    
    #urls for handling http requests
    path('add_note/', views.add_note, name='add_note'),
    path('fetch_notes/', views.fetch_notes, name='fetch_notes'),
    path('remove_note/', views.remove_note, name='remove_note'),
    path('edit_note/', views.edit_note, name='edit_note'),
]