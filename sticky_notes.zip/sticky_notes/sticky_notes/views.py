from .models import Note
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt, csrf_protect, requires_csrf_token

# loading pages for viewing and adding notes
def index(request): return render(request, 'index.html')
def loadAddNote(request): return render(request, 'add_note.html')

#return JSON list of all notes from the database
@csrf_protect
def fetch_notes(request):
	if request.method == 'GET':		
		return JsonResponse({
			'notes' : list(Note.objects.values()), 
		})

# add new note to the database using data from HTML form + ajax call
@csrf_protect
def add_note(request):
	if request.method == 'POST':
		newNote = Note(
			noteTitle = request.POST['titleOfNote'],
			noteDescription = request.POST['descriptionOfNote']
		)
		newNote.save()

		return JsonResponse({'noteTitle' : newNote.noteTitle})
		
# extracting note ID from http request to delete the correct note record from the database
@csrf_exempt
@requires_csrf_token
def remove_note(request):
	if request.method == 'DELETE':
		reqList = str(list(request))
		noteID = reqList.split("'")[1].split("=")[1]
		
		noteToDelete = Note.objects.get(id=noteID)
		noteToDelete.delete()
				
		return JsonResponse({'notes': noteToDelete.noteTitle,})

# extracting note ID from http request to update the correct note record in the database
@csrf_exempt
@requires_csrf_token
def edit_note(request):
	if request.method == 'PUT':
		reqList = str(list(request)).split("'")[1].split("&")

		noteID = reqList[0].split("noteID=")[1]
		noteTitle = reqList[1].split("noteTitleField=")[1]
		noteDescription = reqList[2].split("noteDescriptionField=")[1]

		noteToEdit = Note.objects.get(id=noteID)
		noteToEdit.noteTitle = noteTitle.replace("+", " ")
		noteToEdit.noteDescription = noteDescription.replace("+", " ")

		noteToEdit.save()

		return JsonResponse({'noteID' : reqList,})
