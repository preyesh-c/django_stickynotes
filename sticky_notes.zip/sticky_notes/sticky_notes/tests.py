# Create your tests here.

from django.test import TestCase
from django.urls import reverse
from .models import Note, Author

class NoteModelTest(TestCase):
    def setUp(self):
        # Create an Author object
        author = Author.objects.create(name='Test Author')
        # Create a Note object for testing
        Note.objects.create(noteTitle='Test Note', noteDescription='This is a test note.', author=author)

    def test_note_has_title(self):
        # Test that a Note object has the expected title
        note = Note.objects.get(id=1)
        self.assertEqual(note.noteTitle, 'Test Note')

    def test_note_has_content(self):
        # Test that a Note object has the expected content
        note = Note.objects.get(id=1)
        self.assertEqual(note.noteDescription, 'This is a test note.')

    def test_update_note(self):
        noteToUpdate = Note.objects.get(id=1)
        noteToUpdate.noteTitle = 'Updated Test Note'
        noteToUpdate.save()

        note = Note.objects.get(id=1)
        self.assertEqual(note.noteTitle, 'Updated Test Note')
    def test_delete_note(self):
        noteToDelete = Note.objects.get(id=1)
        noteToDelete.delete()
        self.assertEqual(Note.objects.count(), 0)

class NoteViewTest(TestCase):
    def setUp(self):
        # Create an Author object
        author = Author.objects.create(name='Test Author')
        # Create a Note object for testing views
        Note.objects.create(noteTitle='Test Note', noteDescription='This is a test note.', author=author)

    def test_note_list_view(self):
        # Test the Note-list view
        response = self.client.get(f'/fetch_notes/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')