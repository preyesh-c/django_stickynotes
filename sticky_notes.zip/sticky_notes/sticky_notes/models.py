from django.db import models
	
class Note(models.Model):
	noteTitle = models.CharField(max_length=255)
	noteDescription = models.CharField(max_length=400)
	createdAt = models.DateTimeField(auto_now_add=True)
	author = models.ForeignKey('Author', on_delete=models.CASCADE,null=True, blank=True)

class Author(models.Model):
	name = models.CharField(max_length=255)
